a = int(input("first number"))
b = int(input("second number"))
print(a + b)
